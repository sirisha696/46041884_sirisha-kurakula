package labprograms;

public class Lab5Exercise2 {
	public static void main(String args[]) {
		Lab5Exercise2 le2 = new Lab5Exercise2();
		try {
			System.out.println(le2.validateName("Harika", "U V"));
			System.out.println(le2.validateName(" ", " "));
		}
		catch(InvalidNameException e) {
			System.out.println(e);
		}
	}
	public String validateName(String firstName, String lastName) throws InvalidNameException {
		if(firstName == " " && lastName == " ") {
			throw new InvalidNameException("First name and last name should not be blank");
		}
		else 
			System.out.println("Name is valid");
		return "Name validation";
	}
}
