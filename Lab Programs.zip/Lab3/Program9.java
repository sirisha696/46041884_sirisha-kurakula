package lab3;

	import java.util.Date;
	class program {
	 public static void main(String args[]) {
	  // Instantiate a Date object by invoking its constructor
	  Date objDate = new Date();
	  // Display the Date & Time using toString()
	  System.out.println(objDate.toString());
	 }
	}
