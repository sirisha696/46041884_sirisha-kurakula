//HashSet lab 6 program
package simplilearn;
import java.util.HashSet;
public class HashSetClass {
	public static void main(String args[]) {
		HashSet<String> hset = new HashSet<String>();
		
		hset.add("Suzuki");
		hset.add("Honda");
		hset.add("Maruthi");
		hset.add("Duster");
		hset.add("BMW");
		hset.add("Audi");
		hset.add("Swift");
		hset.add("null");
		hset.add("null");
		
		//Displaying HashSet elements
		System.out.println(hset);
	}

}
