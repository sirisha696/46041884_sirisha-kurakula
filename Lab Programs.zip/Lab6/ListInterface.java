// List Interface lab 6 program
package simplilearn;

import java.util.*;

public class ListInterface {
	public static void main(String args[]) {
		List<String> list = new ArrayList<String>();
		list.add("Lavanya");
		list.add("Swarupa");
		list.add("Satya");
		//list.add("Satya");
		for (String Students : list)
			System.out.println(Students);
	}

}
